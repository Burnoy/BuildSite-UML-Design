package com.buildsite.buildsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuildsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
