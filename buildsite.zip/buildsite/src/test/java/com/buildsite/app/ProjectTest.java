package com.buildsite.app;

import com.buildsite.app.model.Project;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class ProjectTest {
    @Test void progressMustStayWithinZeroAndOneHundred() {
        Project project = new Project("Test", "Mumbai", "Planning", 0, BigDecimal.ZERO, null);
        assertThrows(IllegalArgumentException.class, () -> project.updateProgress(-1));
        assertThrows(IllegalArgumentException.class, () -> project.updateProgress(101));
        project.updateProgress(100);
        assertEquals(100, project.getProgress());
        assertEquals("Completed", project.getStatus());
    }
}
