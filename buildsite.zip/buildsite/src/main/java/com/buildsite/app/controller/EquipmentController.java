
package com.buildsite.app.controller;

import com.buildsite.app.model.Equipment;
import com.buildsite.app.service.EquipmentService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/equipment")
public class EquipmentController {

    private final EquipmentService equipmentService;

    public EquipmentController(EquipmentService equipmentService) {
        this.equipmentService = equipmentService;
    }

    @GetMapping
    public String listEquipment(Model model) {
        model.addAttribute("equipmentList",
                equipmentService.getAllEquipment());
        return "equipment/list";
    }

    @GetMapping("/new")
    public String newEquipment(Model model) {
        model.addAttribute("equipment", new Equipment());
        return "equipment/form";
    }

    @PostMapping
    public String saveEquipment(
            @Valid @ModelAttribute("equipment") Equipment equipment,
            BindingResult result) {

        if (result.hasErrors()) {
            return "equipment/form";
        }

        equipmentService.saveEquipment(equipment);
        return "redirect:/equipment";
    }

    @GetMapping("/edit/{id}")
    public String editEquipment(@PathVariable Long id, Model model) {
        model.addAttribute("equipment",
                equipmentService.getEquipmentById(id));
        return "equipment/form";
    }

    @PostMapping("/delete/{id}")
    public String deleteEquipment(@PathVariable Long id) {
        equipmentService.deleteEquipment(id);
        return "redirect:/equipment";
    }
}
