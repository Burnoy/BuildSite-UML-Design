
package com.buildsite.app.controller;

import com.buildsite.app.model.Worker;
import com.buildsite.app.service.WorkerService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/workforce")
public class WorkerController {

    private final WorkerService workerService;

    public WorkerController(WorkerService workerService) {
        this.workerService = workerService;
    }

    @GetMapping
    public String listWorkers(Model model) {
        model.addAttribute("workers", workerService.getAllWorkers());
        return "workforce/list";
    }

    @GetMapping("/new")
    public String newWorker(Model model) {
        model.addAttribute("worker", new Worker());
        return "workforce/form";
    }

    @PostMapping
    public String saveWorker(
            @Valid @ModelAttribute("worker") Worker worker,
            BindingResult result) {

        if (result.hasErrors()) {
            return "workforce/form";
        }

        workerService.saveWorker(worker);
        return "redirect:/workforce";
    }

    @GetMapping("/edit/{id}")
    public String editWorker(@PathVariable Long id, Model model) {
        model.addAttribute("worker", workerService.getWorkerById(id));
        return "workforce/form";
    }

    @PostMapping("/delete/{id}")
    public String deleteWorker(@PathVariable Long id) {
        workerService.deleteWorker(id);
        return "redirect:/workforce";
    }
}
