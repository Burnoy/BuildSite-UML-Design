package com.buildsite.app.oop;
public interface Assignable { void assignTo(String person); }
