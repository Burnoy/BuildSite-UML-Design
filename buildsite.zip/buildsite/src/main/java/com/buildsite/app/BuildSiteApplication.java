package com.buildsite.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuildSiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(BuildSiteApplication.class, args);
    }
}
