package com.buildsite.app.oop;
public class SiteEngineer extends User implements Assignable, Notifiable {
    private String assignedProject = "Unassigned";
    public SiteEngineer(String name, String email) { super(name, email); }
    @Override public String getRole() { return "Site Engineer"; }
    @Override public void assignTo(String person) { assignedProject = person; }
    @Override public String getNotificationMessage() { return "Site engineer " + getName() + " is assigned to " + assignedProject; }
}
