package com.buildsite.app.repository;
import com.buildsite.app.model.Material;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MaterialRepository extends JpaRepository<Material, Long> { long countByQuantityLessThanEqual(int quantity); }
