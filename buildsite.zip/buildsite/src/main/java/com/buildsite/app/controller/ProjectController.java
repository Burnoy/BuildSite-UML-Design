package com.buildsite.app.controller;
import com.buildsite.app.model.Project;
import com.buildsite.app.repository.ProjectRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
@Controller @RequestMapping("/projects")
public class ProjectController {
    private final ProjectRepository projects;
    public ProjectController(ProjectRepository projects) { this.projects = projects; }
    @GetMapping public String list(Model model) { model.addAttribute("projects", projects.findAll()); model.addAttribute("pageTitle", "Projects"); model.addAttribute("active", "projects"); return "projects/list"; }
    @GetMapping("/new") public String createForm(Model model) { model.addAttribute("project", new Project()); model.addAttribute("pageTitle", "New project"); model.addAttribute("active", "projects"); return "projects/form"; }
    @PostMapping public String save(@Valid @ModelAttribute Project project, BindingResult result, Model model, RedirectAttributes redirect) {
        if (result.hasErrors()) { model.addAttribute("pageTitle", "New project"); model.addAttribute("active", "projects"); return "projects/form"; }
        projects.save(project); redirect.addFlashAttribute("successMessage", "Project saved successfully."); return "redirect:/projects";
    }
    @GetMapping("/{id}/edit") public String edit(@PathVariable Long id, Model model) { model.addAttribute("project", projects.findById(id).orElseThrow()); model.addAttribute("pageTitle", "Edit project"); model.addAttribute("active", "projects"); return "projects/form"; }
    @PostMapping("/{id}") public String update(@PathVariable Long id, @Valid @ModelAttribute Project project, BindingResult result, Model model, RedirectAttributes redirect) {
        if (result.hasErrors()) { model.addAttribute("pageTitle", "Edit project"); model.addAttribute("active", "projects"); return "projects/form"; }
        Project existing = projects.findById(id).orElseThrow();
        existing.setName(project.getName()); existing.setLocation(project.getLocation()); existing.setStatus(project.getStatus());
        existing.setProgress(project.getProgress()); existing.setBudget(project.getBudget()); existing.setDueDate(project.getDueDate());
        projects.save(existing); redirect.addFlashAttribute("successMessage", "Project updated successfully."); return "redirect:/projects";
    }
    @PostMapping("/{id}/delete") public String delete(@PathVariable Long id, RedirectAttributes redirect) { projects.deleteById(id); redirect.addFlashAttribute("successMessage", "Project deleted."); return "redirect:/projects"; }
}
