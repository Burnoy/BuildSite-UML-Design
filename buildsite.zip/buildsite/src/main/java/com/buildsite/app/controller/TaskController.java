package com.buildsite.app.controller;
import com.buildsite.app.model.TaskItem;
import com.buildsite.app.repository.ProjectRepository;
import com.buildsite.app.repository.TaskRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
@Controller @RequestMapping("/tasks")
public class TaskController {
    private final TaskRepository tasks; private final ProjectRepository projects;
    public TaskController(TaskRepository tasks, ProjectRepository projects) { this.tasks=tasks; this.projects=projects; }
    @GetMapping public String list(Model model) { model.addAttribute("tasks", tasks.findAll()); model.addAttribute("pageTitle", "Tasks & schedule"); model.addAttribute("active", "tasks"); return "tasks/list"; }
    @GetMapping("/new") public String form(Model model) { model.addAttribute("task", new TaskItem()); model.addAttribute("projects", projects.findAll()); model.addAttribute("pageTitle", "New task"); model.addAttribute("active", "tasks"); return "tasks/form"; }
    @PostMapping public String save(@Valid @ModelAttribute("task") TaskItem task, BindingResult result, @RequestParam(required=false) Long projectId, Model model, RedirectAttributes redirect) {
        if (projectId != null) task.setProject(projects.findById(projectId).orElse(null));
        if (result.hasErrors()) { model.addAttribute("projects", projects.findAll()); model.addAttribute("pageTitle", "New task"); model.addAttribute("active", "tasks"); return "tasks/form"; }
        tasks.save(task); redirect.addFlashAttribute("successMessage", "Task saved successfully."); return "redirect:/tasks";
    }
    @PostMapping("/{id}/delete") public String delete(@PathVariable Long id, RedirectAttributes redirect) { tasks.deleteById(id); redirect.addFlashAttribute("successMessage", "Task deleted."); return "redirect:/tasks"; }
}
