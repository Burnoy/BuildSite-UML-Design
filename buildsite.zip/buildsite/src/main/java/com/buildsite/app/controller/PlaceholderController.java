package com.buildsite.app.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class PlaceholderController {
    private String show(Model model, String title, String active) { model.addAttribute("pageTitle", title); model.addAttribute("active", active); return "coming-soon"; }
    
    
    
    
    
}
