package com.buildsite.app.oop;
public interface Reportable { String generateSummary(); }
