
package com.buildsite.app.controller;

import com.buildsite.app.model.Expense;
import com.buildsite.app.model.Project;
import com.buildsite.app.repository.ProjectRepository;
import com.buildsite.app.service.ExpenseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/reports")
public class ReportsController {

    private final ProjectRepository projectRepository;
    private final ExpenseService expenseService;

    public ReportsController(
            ProjectRepository projectRepository,
            ExpenseService expenseService) {
        this.projectRepository = projectRepository;
        this.expenseService = expenseService;
    }

    @GetMapping
    public String showReports(Model model) {
        List<Project> projects = projectRepository.findAll();
        List<Expense> expenses = expenseService.getAllExpenses();

        BigDecimal totalBudget = BigDecimal.ZERO;
        BigDecimal totalExpenses = BigDecimal.ZERO;
        int completedProjects = 0;
        int totalProgress = 0;

        Map<String, BigDecimal> categoryTotals = new LinkedHashMap<>();

        for (Expense expense : expenses) {
            BigDecimal amount = expense.getAmount() == null
                    ? BigDecimal.ZERO : expense.getAmount();

            totalExpenses = totalExpenses.add(amount);

            String category = expense.getCategory() == null
                    || expense.getCategory().isBlank()
                    ? "Other" : expense.getCategory();

            categoryTotals.merge(category, amount, BigDecimal::add);
        }

        for (Project project : projects) {
            if (project.getBudget() != null) {
                totalBudget = totalBudget.add(project.getBudget());
            }

            totalProgress += project.getProgress();

            if ("Completed".equalsIgnoreCase(project.getStatus())) {
                completedProjects++;
            }
        }

        BigDecimal remainingBudget = totalBudget.subtract(totalExpenses);

        double averageProgress = projects.isEmpty()
                ? 0.0
                : (double) totalProgress / projects.size();

        double budgetUsed = totalBudget.compareTo(BigDecimal.ZERO) > 0
                ? totalExpenses.multiply(BigDecimal.valueOf(100))
                    .divide(totalBudget, 2, RoundingMode.HALF_UP)
                    .doubleValue()
                : 0.0;

        List<Map<String, Object>> categorySummaries = new ArrayList<>();

        for (Map.Entry<String, BigDecimal> entry : categoryTotals.entrySet()) {
            double percentage = totalExpenses.compareTo(BigDecimal.ZERO) > 0
                    ? entry.getValue()
                        .multiply(BigDecimal.valueOf(100))
                        .divide(totalExpenses, 2, RoundingMode.HALF_UP)
                        .doubleValue()
                    : 0.0;

            Map<String, Object> summary = new HashMap<>();
            summary.put("name", entry.getKey());
            summary.put("amount", entry.getValue());
            summary.put("percentage", percentage);

            categorySummaries.add(summary);
        }

        List<Map<String, Object>> projectSummaries = new ArrayList<>();

        for (Project project : projects) {
            BigDecimal budget = project.getBudget() == null
                    ? BigDecimal.ZERO : project.getBudget();

            BigDecimal spent = BigDecimal.ZERO;

            for (Expense expense : expenses) {
                if (expense.getProject() != null
                        && expense.getProject().getId().equals(project.getId())
                        && expense.getAmount() != null) {
                    spent = spent.add(expense.getAmount());
                }
            }

            double projectBudgetUsed = budget.compareTo(BigDecimal.ZERO) > 0
                    ? spent.multiply(BigDecimal.valueOf(100))
                        .divide(budget, 2, RoundingMode.HALF_UP)
                        .doubleValue()
                    : 0.0;

            Map<String, Object> summary = new HashMap<>();
            summary.put("project", project);
            summary.put("budget", budget);
            summary.put("spent", spent);
            summary.put("remaining", budget.subtract(spent));
            summary.put("budgetUsed", projectBudgetUsed);
            summary.put("progressWidth",
                    Math.max(0, Math.min(100, project.getProgress())));
            summary.put("overBudget", spent.compareTo(budget) > 0);

            projectSummaries.add(summary);
        }

        model.addAttribute("totalProjects", projects.size());
        model.addAttribute("completedProjects", completedProjects);
        model.addAttribute("averageProgress", averageProgress);
        model.addAttribute("totalBudget", totalBudget);
        model.addAttribute("totalExpenses", totalExpenses);
        model.addAttribute("remainingBudget", remainingBudget);
        model.addAttribute("budgetUsed", budgetUsed);
        model.addAttribute("categorySummaries", categorySummaries);
        model.addAttribute("projectSummaries", projectSummaries);

        return "reports/list";
    }
}
