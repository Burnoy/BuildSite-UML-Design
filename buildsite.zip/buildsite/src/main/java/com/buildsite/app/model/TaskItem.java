package com.buildsite.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "task_items")
public class TaskItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @NotBlank @Size(max = 120) private String title;
    @NotBlank private String assignedTo;
    @NotBlank private String status = "To Do";
    @Min(0) @Max(100) private int progress;
    private LocalDate dueDate;
    @ManyToOne(fetch = FetchType.EAGER) private Project project;
    public TaskItem() {}
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String assignedTo) { this.assignedTo = assignedTo; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getProgress() { return progress; }
    public void setProgress(int progress) { if (progress < 0 || progress > 100) throw new IllegalArgumentException("Progress must be between 0 and 100."); this.progress = progress; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public Project getProject() { return project; }
    public void setProject(Project project) { this.project = project; }
}
