
package com.buildsite.app.controller;

import com.buildsite.app.model.Expense;
import com.buildsite.app.model.Project;
import com.buildsite.app.repository.ProjectRepository;
import com.buildsite.app.service.ExpenseService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/expenses")
public class ExpenseController {

    private final ExpenseService expenseService;
    private final ProjectRepository projectRepository;

    public ExpenseController(
            ExpenseService expenseService,
            ProjectRepository projectRepository) {
        this.expenseService = expenseService;
        this.projectRepository = projectRepository;
    }

    private void addProjects(Model model) {
        model.addAttribute("projects", projectRepository.findAll());
    }

    @GetMapping
    public String listExpenses(Model model) {
        List<Expense> expenses = expenseService.getAllExpenses();
        List<Project> projects = projectRepository.findAll();

        BigDecimal totalExpenses = BigDecimal.ZERO;

        for (Expense expense : expenses) {
            if (expense.getAmount() != null) {
                totalExpenses = totalExpenses.add(expense.getAmount());
            }
        }

        BigDecimal totalBudget = BigDecimal.ZERO;

        for (Project project : projects) {
            if (project.getBudget() != null) {
                totalBudget = totalBudget.add(project.getBudget());
            }
        }

        BigDecimal remainingBudget = totalBudget.subtract(totalExpenses);

        // Build a separate budget summary for every project.
        List<Map<String, Object>> projectSummaries = new ArrayList<>();

        for (Project project : projects) {
            BigDecimal budget = project.getBudget() == null
                    ? BigDecimal.ZERO : project.getBudget();

            BigDecimal spent = BigDecimal.ZERO;

            for (Expense expense : expenses) {
                if (expense.getProject() != null
                        && expense.getProject().getId().equals(project.getId())
                        && expense.getAmount() != null) {
                    spent = spent.add(expense.getAmount());
                }
            }

            BigDecimal remaining = budget.subtract(spent);

            BigDecimal percentage = BigDecimal.ZERO;

            if (budget.compareTo(BigDecimal.ZERO) > 0) {
                percentage = spent.multiply(BigDecimal.valueOf(100))
                        .divide(budget, 2, RoundingMode.HALF_UP);
            } else if (spent.compareTo(BigDecimal.ZERO) > 0) {
                percentage = BigDecimal.valueOf(100);
            }

            // Keep the visual progress bar within 0–100%.
            double progressWidth = Math.max(
                    0, Math.min(100, percentage.doubleValue()));

            Map<String, Object> summary = new HashMap<>();
            summary.put("project", project);
            summary.put("budget", budget);
            summary.put("spent", spent);
            summary.put("remaining", remaining);
            summary.put("percentage", percentage);
            summary.put("progressWidth", progressWidth);
            summary.put("overBudget", spent.compareTo(budget) > 0);

            projectSummaries.add(summary);
        }

        model.addAttribute("expenses", expenses);
        model.addAttribute("totalExpenses", totalExpenses);
        model.addAttribute("totalBudget", totalBudget);
        model.addAttribute("remainingBudget", remainingBudget);
        model.addAttribute("projectSummaries", projectSummaries);

        return "expenses/list";
    }

    @GetMapping("/new")
    public String newExpense(Model model) {
        model.addAttribute("expense", new Expense());
        addProjects(model);
        return "expenses/form";
    }

    @PostMapping
    public String saveExpense(
            @Valid @ModelAttribute("expense") Expense expense,
            BindingResult result,
            @RequestParam(value = "projectId", required = false)
            Long projectId,
            Model model) {

        if (projectId == null) {
            result.rejectValue(
                    "project", "required", "Please select a project.");
        }

        if (result.hasErrors()) {
            addProjects(model);
            return "expenses/form";
        }

        expenseService.saveExpense(expense, projectId);
        return "redirect:/expenses";
    }

    @GetMapping("/edit/{id}")
    public String editExpense(
            @PathVariable Long id,
            Model model) {
        model.addAttribute("expense", expenseService.getExpenseById(id));
        addProjects(model);
        return "expenses/form";
    }

    @PostMapping("/delete/{id}")
    public String deleteExpense(@PathVariable Long id) {
        expenseService.deleteExpense(id);
        return "redirect:/expenses";
    }
}
