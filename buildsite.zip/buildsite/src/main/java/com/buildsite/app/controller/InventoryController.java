package com.buildsite.app.controller;
import com.buildsite.app.model.Material;
import com.buildsite.app.repository.MaterialRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
@Controller @RequestMapping("/inventory")
public class InventoryController {
    private final MaterialRepository materials;
    public InventoryController(MaterialRepository materials) { this.materials=materials; }
    @GetMapping public String list(Model model) { model.addAttribute("materials", materials.findAll()); model.addAttribute("pageTitle", "Materials & inventory"); model.addAttribute("active", "inventory"); return "inventory/list"; }
    @GetMapping("/new") public String form(Model model) { model.addAttribute("material", new Material()); model.addAttribute("pageTitle", "Add material"); model.addAttribute("active", "inventory"); return "inventory/form"; }
    @PostMapping public String save(@Valid @ModelAttribute Material material, BindingResult result, Model model, RedirectAttributes redirect) {
        if (result.hasErrors()) { model.addAttribute("pageTitle", "Add material"); model.addAttribute("active", "inventory"); return "inventory/form"; }
        materials.save(material); redirect.addFlashAttribute("successMessage", "Material saved successfully."); return "redirect:/inventory";
    }
    @PostMapping("/{id}/receive") public String receive(@PathVariable Long id, @RequestParam int quantity, RedirectAttributes redirect) {
        if (quantity <= 0) { redirect.addFlashAttribute("errorMessage", "Receive quantity must be greater than zero."); return "redirect:/inventory"; }
        Material material = materials.findById(id).orElseThrow(); material.setQuantity(Math.addExact(material.getQuantity(), quantity)); materials.save(material);
        redirect.addFlashAttribute("successMessage", quantity + " " + material.getUnit() + " received for " + material.getName() + "."); return "redirect:/inventory";
    }
    @PostMapping("/{id}/issue") public String issue(@PathVariable Long id, @RequestParam int quantity, RedirectAttributes redirect) {
        Material material = materials.findById(id).orElseThrow();
        if (quantity <= 0 || quantity > material.getQuantity()) { redirect.addFlashAttribute("errorMessage", "Issue quantity must be positive and cannot exceed available stock."); return "redirect:/inventory"; }
        material.setQuantity(material.getQuantity() - quantity); materials.save(material); redirect.addFlashAttribute("successMessage", quantity + " " + material.getUnit() + " issued from " + material.getName() + "."); return "redirect:/inventory";
    }
}
