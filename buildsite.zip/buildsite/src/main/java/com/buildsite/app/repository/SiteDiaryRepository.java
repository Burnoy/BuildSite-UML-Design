
package com.buildsite.app.repository;

import com.buildsite.app.model.SiteDiary;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SiteDiaryRepository extends JpaRepository<SiteDiary, Long> {

    List<SiteDiary> findAllByOrderByReportDateDesc();

}
