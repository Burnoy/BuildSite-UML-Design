
package com.buildsite.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "site_diary")
public class SiteDiary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "project_id", nullable = false)
    
    private Project project;

    @NotNull
    private LocalDate reportDate = LocalDate.now();

    @NotBlank
    private String weather = "Sunny";

    @Min(0)
    private int workersPresent;

    @NotBlank
    @Column(length = 3000)
    private String workCompleted;

    @Column(length = 3000)
    private String issues;

    public SiteDiary() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Project getProject() { return project; }
    public void setProject(Project project) { this.project = project; }

    public LocalDate getReportDate() { return reportDate; }
    public void setReportDate(LocalDate reportDate) { this.reportDate = reportDate; }

    public String getWeather() { return weather; }
    public void setWeather(String weather) { this.weather = weather; }

    public int getWorkersPresent() { return workersPresent; }
    public void setWorkersPresent(int workersPresent) { this.workersPresent = workersPresent; }

    public String getWorkCompleted() { return workCompleted; }
    public void setWorkCompleted(String workCompleted) { this.workCompleted = workCompleted; }

    public String getIssues() { return issues; }
    public void setIssues(String issues) { this.issues = issues; }
}
