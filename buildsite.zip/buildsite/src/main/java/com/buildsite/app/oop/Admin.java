package com.buildsite.app.oop;
public class Admin extends User implements Approvable {
    public Admin(String name, String email) { super(name, email); }
    @Override public String getRole() { return "Administrator"; }
    @Override public boolean approve(String approver) { return approver != null && !approver.isBlank(); }
}
