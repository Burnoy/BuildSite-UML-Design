
package com.buildsite.app.repository;

import com.buildsite.app.model.Equipment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipmentRepository
        extends JpaRepository<Equipment, Long> {
}
