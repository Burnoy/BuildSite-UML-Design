package com.buildsite.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "projects")
public class Project {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Size(max = 100)
    private String name;
    @NotBlank @Size(max = 120)
    private String location;
    @NotBlank
    private String status = "Planning";
    @Min(0) @Max(100)
    private int progress;
    @NotNull @DecimalMin(value = "0.0", inclusive = true)
    @Column(precision = 14, scale = 2)
    private BigDecimal budget = BigDecimal.ZERO;
    private LocalDate dueDate;

    public Project() {}
    public Project(String name, String location, String status, int progress, BigDecimal budget, LocalDate dueDate) {
        this.name = name; this.location = location; this.status = status; this.progress = progress; this.budget = budget; this.dueDate = dueDate;
    }
    public void updateProgress(int value) {
        if (value < 0 || value > 100) throw new IllegalArgumentException("Progress must be between 0 and 100.");
        this.progress = value;
        if (value == 100) this.status = "Completed";
        else if ("Completed".equals(this.status)) this.status = "In Progress";
    }
    public Long getId() { return id; }
    public void setIdForUpdate(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getProgress() { return progress; }
    public void setProgress(int progress) { updateProgress(progress); }
    public BigDecimal getBudget() { return budget; }
    public void setBudget(BigDecimal budget) { this.budget = budget; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
}
