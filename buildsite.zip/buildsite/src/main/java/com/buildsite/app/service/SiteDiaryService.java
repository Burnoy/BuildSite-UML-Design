
package com.buildsite.app.service;

import com.buildsite.app.model.Project;
import com.buildsite.app.model.SiteDiary;
import com.buildsite.app.repository.ProjectRepository;
import com.buildsite.app.repository.SiteDiaryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class SiteDiaryService {

    private final SiteDiaryRepository diaryRepository;
    private final ProjectRepository projectRepository;

    public SiteDiaryService(
            SiteDiaryRepository diaryRepository,
            ProjectRepository projectRepository) {
        this.diaryRepository = diaryRepository;
        this.projectRepository = projectRepository;
    }

    public List<SiteDiary> getAllEntries() {
        return diaryRepository.findAllByOrderByReportDateDesc();
    }

    public SiteDiary getEntryById(Long id) {
        return diaryRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Diary entry not found: " + id));
    }

    @Transactional
    public SiteDiary saveEntry(SiteDiary entry, Long projectId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Project not found: " + projectId));

        entry.setProject(project);
        return diaryRepository.save(entry);
    }

    public void deleteEntry(Long id) {
        diaryRepository.deleteById(id);
    }
}
