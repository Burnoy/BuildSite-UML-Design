package com.buildsite.app.oop;
public interface Notifiable { String getNotificationMessage(); }
