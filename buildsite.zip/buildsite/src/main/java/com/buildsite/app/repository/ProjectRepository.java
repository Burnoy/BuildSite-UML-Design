package com.buildsite.app.repository;
import com.buildsite.app.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProjectRepository extends JpaRepository<Project, Long> { long countByStatusIgnoreCase(String status); }
