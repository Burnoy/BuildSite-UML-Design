package com.buildsite.app.controller;
import com.buildsite.app.oop.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;
@Controller
public class OopController {
    @GetMapping("/oop-demo") public String demo(Model model) {
        List<User> users = List.of(new Admin("Aarav Shah", "admin@buildsite.local"), new SiteEngineer("Sara Khan", "engineer@buildsite.local"), new Storekeeper("Rohan Mehta", "store@buildsite.local"));
        model.addAttribute("users", users); model.addAttribute("pageTitle", "Java OOP lab"); model.addAttribute("active", "oop"); return "oop-demo";
    }
}
