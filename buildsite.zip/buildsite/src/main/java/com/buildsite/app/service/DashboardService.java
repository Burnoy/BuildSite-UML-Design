package com.buildsite.app.service;
import com.buildsite.app.repository.*;
import org.springframework.stereotype.Service;
import java.util.Map;
@Service
public class DashboardService {
    private final ProjectRepository projects; private final TaskRepository tasks; private final MaterialRepository materials;
    public DashboardService(ProjectRepository projects, TaskRepository tasks, MaterialRepository materials) { this.projects = projects; this.tasks = tasks; this.materials = materials; }
    public Map<String, Object> metrics() {
        return Map.of("projects", projects.count(), "activeProjects", projects.countByStatusIgnoreCase("In Progress"), "tasks", tasks.count(), "openTasks", tasks.countByStatusIgnoreCase("To Do"), "materials", materials.count(), "lowStock", materials.findAll().stream().filter(m -> m.isLowStock()).count());
    }
}
