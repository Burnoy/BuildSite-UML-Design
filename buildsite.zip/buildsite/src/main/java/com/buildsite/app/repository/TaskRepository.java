package com.buildsite.app.repository;
import com.buildsite.app.model.TaskItem;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TaskRepository extends JpaRepository<TaskItem, Long> { long countByStatusIgnoreCase(String status); }
