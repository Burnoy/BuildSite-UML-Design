package com.buildsite.app.config;

import com.buildsite.app.model.*;
import com.buildsite.app.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DataSeeder {
    @Bean CommandLineRunner seedData(ProjectRepository projects, TaskRepository tasks, MaterialRepository materials) {
        return args -> {
            if (projects.count() == 0) {
                Project p1 = projects.save(new Project("Skyline Residency", "Andheri East, Mumbai", "In Progress", 68, new BigDecimal("18500000"), LocalDate.now().plusDays(48)));
                Project p2 = projects.save(new Project("Harbour View Offices", "Bandra Kurla Complex", "Planning", 12, new BigDecimal("9200000"), LocalDate.now().plusDays(95)));
                projects.save(new Project("Cedar Heights", "Powai, Mumbai", "In Progress", 41, new BigDecimal("12750000"), LocalDate.now().plusDays(70)));
                TaskItem t1 = new TaskItem(); t1.setTitle("Complete 4th-floor slab"); t1.setAssignedTo("Rohan Mehta"); t1.setStatus("In Progress"); t1.setProgress(65); t1.setDueDate(LocalDate.now().plusDays(4)); t1.setProject(p1); tasks.save(t1);
                TaskItem t2 = new TaskItem(); t2.setTitle("Electrical layout inspection"); t2.setAssignedTo("Sara Khan"); t2.setStatus("To Do"); t2.setProgress(0); t2.setDueDate(LocalDate.now().plusDays(7)); t2.setProject(p1); tasks.save(t2);
                TaskItem t3 = new TaskItem(); t3.setTitle("Site boundary survey"); t3.setAssignedTo("Dev Patel"); t3.setStatus("To Do"); t3.setProgress(0); t3.setDueDate(LocalDate.now().plusDays(12)); t3.setProject(p2); tasks.save(t3);
            }
            if (materials.count() == 0) {
                saveMaterial(materials, "OPC Cement", "Cement & Concrete", "bags", 34, 50);
                saveMaterial(materials, "TMT Steel Bars", "Steel", "tonnes", 18, 10);
                saveMaterial(materials, "River Sand", "Aggregates", "tonnes", 7, 15);
                saveMaterial(materials, "Hollow Blocks", "Masonry", "pieces", 840, 300);
            }
        };
    }
    private void saveMaterial(MaterialRepository repo, String name, String category, String unit, int quantity, int reorder) {
        Material m = new Material(); m.setName(name); m.setCategory(category); m.setUnit(unit); m.setQuantity(quantity); m.setReorderLevel(reorder); repo.save(m);
    }
}
