package com.buildsite.app.oop;
public class Storekeeper extends User implements Notifiable {
    public Storekeeper(String name, String email) { super(name, email); }
    @Override public String getRole() { return "Storekeeper"; }
    @Override public String getNotificationMessage() { return "Inventory check required for the store."; }
}
