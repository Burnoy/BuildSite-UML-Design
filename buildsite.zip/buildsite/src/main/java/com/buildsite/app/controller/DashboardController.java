package com.buildsite.app.controller;
import com.buildsite.app.service.DashboardService;
import com.buildsite.app.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class DashboardController {
    private final DashboardService dashboard; private final ProjectRepository projects; private final TaskRepository tasks; private final MaterialRepository materials;
    public DashboardController(DashboardService dashboard, ProjectRepository projects, TaskRepository tasks, MaterialRepository materials) { this.dashboard=dashboard; this.projects=projects; this.tasks=tasks; this.materials=materials; }
    @GetMapping("/") public String home(Model model) {
        model.addAttribute("metrics", dashboard.metrics());
        model.addAttribute("projects", projects.findAll().stream().limit(5).toList());
        model.addAttribute("tasks", tasks.findAll().stream().limit(5).toList());
        model.addAttribute("lowStockItems", materials.findAll().stream().filter(m -> m.isLowStock()).toList());
        model.addAttribute("pageTitle", "Overview"); model.addAttribute("active", "dashboard");
        return "dashboard";
    }
}
