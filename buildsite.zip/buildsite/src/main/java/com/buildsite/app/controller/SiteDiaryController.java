
package com.buildsite.app.controller;

import com.buildsite.app.model.Project;
import com.buildsite.app.model.SiteDiary;
import com.buildsite.app.repository.ProjectRepository;
import com.buildsite.app.service.SiteDiaryService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/site-diary")
public class SiteDiaryController {

    private final SiteDiaryService diaryService;
    private final ProjectRepository projectRepository;

    public SiteDiaryController(
            SiteDiaryService diaryService,
            ProjectRepository projectRepository) {
        this.diaryService = diaryService;
        this.projectRepository = projectRepository;
    }

    private void addProjects(Model model) {
        model.addAttribute("projects", projectRepository.findAll());
    }

    @GetMapping
    public String listEntries(Model model) {
        model.addAttribute("entries", diaryService.getAllEntries());
        return "diary/list";
    }

    @GetMapping("/new")
    public String newEntry(Model model) {
        model.addAttribute("entry", new SiteDiary());
        addProjects(model);
        return "diary/form";
    }

    @PostMapping
    public String saveEntry(
            @Valid @ModelAttribute("entry") SiteDiary entry,
            BindingResult result,
            @RequestParam(value = "projectId", required = false) Long projectId,
            Model model) {

        if (projectId == null) {
            result.rejectValue("project", "required",
                    "Please select a project.");
        }

        if (result.hasErrors()) {
            addProjects(model);
            return "diary/form";
        }

        diaryService.saveEntry(entry, projectId);
        return "redirect:/site-diary";
    }

    @GetMapping("/edit/{id}")
    public String editEntry(@PathVariable Long id, Model model) {
        model.addAttribute("entry", diaryService.getEntryById(id));
        addProjects(model);
        return "diary/form";
    }

    @PostMapping("/delete/{id}")
    public String deleteEntry(@PathVariable Long id) {
        diaryService.deleteEntry(id);
        return "redirect:/site-diary";
    }
}
