package com.buildsite.app.oop;
public interface Approvable { boolean approve(String approver); }
