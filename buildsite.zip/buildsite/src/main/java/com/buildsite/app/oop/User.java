package com.buildsite.app.oop;

/** Abstraction + encapsulation: common user data is private and exposed through methods. */
public abstract class User {
    private final String name;
    private final String email;
    protected User(String name, String email) { this.name = name; this.email = email; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public abstract String getRole();
    public String dashboardMessage() { return "Welcome, " + name; }
}
