@echo off
cd /d "%~dp0"
echo Starting BuildSite. Keep this window open while using the website.
mvn spring-boot:run
pause
