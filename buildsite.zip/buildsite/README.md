# BuildSite — Construction Operations Platform (Phase 1)

BuildSite is a Java web application starter for a construction-site management project. It uses Spring Boot, Thymeleaf, Spring Data JPA and a local H2 database.

## Phase 1 features
- Responsive construction operations dashboard with live metrics calculated from database records
- Project list, create, edit and delete
- Task list and creation, with project assignment
- Inventory list, add material, receive stock and issue stock
- Validation that prevents negative stock and issuing more than the available balance
- Java OOP demo page: inheritance, abstraction, encapsulation, interfaces and runtime polymorphism
- Sample records are seeded on first run
- Additional navigation modules are marked as coming in later phases

## Requirements
- JDK 17 or newer
- Maven 3.9+ (or Maven support in your IDE)
- VS Code with the Extension Pack for Java, or IntelliJ IDEA

## Run on Windows
1. Install a JDK if needed. Open Command Prompt and run `java -version` and `mvn -version`.
2. Extract this folder somewhere easy to find, such as `C:\Projects\buildsite`.
3. Open the `buildsite` folder in VS Code.
4. Open the VS Code terminal (**Terminal → New Terminal**).
5. Run:
   ```powershell
   mvn spring-boot:run
   ```
6. Wait until the terminal says the application has started, then open `http://localhost:8080` in your browser.

If PowerShell says `mvn` is not recognized, install Maven and add its `bin` folder to your PATH, or open the project in IntelliJ and use its Maven tool window.

## Database
The H2 database is stored locally in `buildsite-db.mv.db` in the folder from which the application is launched. It persists between restarts. The optional H2 console is at `http://localhost:8080/h2-console` with JDBC URL `jdbc:h2:file:./buildsite-db`, username `sa`, and an empty password. Do not expose the H2 console publicly.

## Important limitations in this phase
- This is a local development/demo application, not a production-secured service.
- Login, user permissions, audit logging, attendance, expenses, equipment maintenance, site diary, CSV reports and formal stock transaction history are planned for later phases.
- The example staff roles on the OOP page demonstrate Java inheritance/polymorphism; they are not authentication accounts.
- Starter sample data is only inserted when the relevant tables are empty.

## Project layout
- `controller/`: HTTP routes and form handling
- `model/`: JPA domain models and validation
- `repository/`: database access interfaces
- `service/`: dashboard business logic
- `oop/`: Java OOP concepts demonstrated by the project
- `resources/templates/`: Thymeleaf pages
- `resources/static/css/style.css`: responsive UI styling

## OOP concepts represented
- **Inheritance:** `Admin`, `SiteEngineer`, `Storekeeper` extend `User`.
- **Abstraction:** `User` is abstract and requires subclasses to implement `getRole()`.
- **Encapsulation:** fields are private and accessed via methods; `Project.updateProgress()` validates the allowed range.
- **Interfaces:** `Approvable`, `Assignable`, `Notifiable`, `Reportable` describe behaviours.
- **Runtime polymorphism:** `List<User>` stores different subclasses and calls the overridden `getRole()` implementation.
- **Wrapper classes:** numeric model fields and repository counts use Java wrapper types; we'll add a dedicated wrapper-class demonstration in the OOP phase.
